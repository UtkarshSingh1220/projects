# About

Mini Projects Typing game written in C. It's pretty feature complete, except for
stretch goals I may pick up in my free time.


			Detail of projects are Mentioned here
 
You need:
---------

* windows time dos and conio headers and library
* gcc 7.3.0 compiler


To compile  and run:
--------------------

	in cmd: go to the project folder 
	gcc -o main ./main.c
	main

Features:
---------
	modes:
	First easy mode which have the only UPPER case. 
	Second  Normal Mode which have the only lower case.
	Third have both UPPer and lower cases.

	It also have to change the time limit 30 sec,1min and 2min.
	It also have the help function for the steps of this game

Instructions:
-------------
	Enter your name as player name.
	Set the time limit under option 3 in main menu(default limit is 30 sec).
	select the level and get started.
	Characters are displayed and you have to type them as fast as you can.
	Avoid incorrect typing otherwise game will be over.


Future/Stretch Goals
--------------------

	It will be upgraded with special characters and numeric character 
	User can change time limit as a user input
 	Increasing levels also have to increase time
