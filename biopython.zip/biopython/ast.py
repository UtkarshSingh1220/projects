from Bio import pairwise2
from Bio.pairwise2 import format_alignment
r = "ABBCDD"
s = "ABBC"
usr = pairwise2.align.globalxx(r, s)
for a in usr:
    print(format_alignment(*a))

usr = pairwise2.align.localxx(r, s)
for a in usr:
    print(format_alignment(*a))
