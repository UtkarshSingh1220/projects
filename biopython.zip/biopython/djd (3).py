import sys
import re

with open("swiss.dat", "r+") as file:
    lines = file.readlines()
seq1 = []
seq2 = []
for line in lines:
    line = line.strip()
    if line.startswith('ID'):
        aa = (line.split())[1]
        

    if line.startswith('OS'):
        bb = (line[5:-2])

        if (bb == ("APP")):
           seq1.append(aa)
        if (bb == ("BANA")):
           seq2.append(aa)


print(seq1)
print(seq2)

def intersection(lst1, lst2):
    lst3 = [value for value in lst1 if value in lst2]
    return lst3
print(intersection(seq1, seq2))
