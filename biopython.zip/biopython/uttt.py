import sys
a="ATRRBBCRRD"
b="AJHFKFKSTRRRD"
def longest(a,b,c,d):
    if (c==0 or d==0):
        return 0
    elif (a[c-1]==b[d-1]):
        return 1+longest(a,b,c-1,d-1)
    else:
        return max(longest(a,b,c-1,d),longest(a,b,c,d-1))
print(longest(a,b,len(a),len(b)))
